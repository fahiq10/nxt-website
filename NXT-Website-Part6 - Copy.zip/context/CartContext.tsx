'use client';
import {createContext,useContext,useState} from 'react';

const CartContext=createContext<any>(null);

export function CartProvider({children}:{children:React.ReactNode}){
 const [cart,setCart]=useState<any[]>([]);
 const addToCart=(item:any)=>setCart(prev=>[...prev,item]);
 const removeFromCart=(i:number)=>setCart(prev=>prev.filter((_,x)=>x!==i));
 return <CartContext.Provider value={{cart,addToCart,removeFromCart}}>{children}</CartContext.Provider>;
}
export const useCart=()=>useContext(CartContext);
