'use client';
import {useCart} from '../context/CartContext';
export default function CartIcon(){
const {cart}=useCart();
return <a href="/cart">🛒 ({cart.length})</a>;
}
