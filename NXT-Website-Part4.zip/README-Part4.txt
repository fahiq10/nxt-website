Create public/products and rename your uploaded photos:
signature.jpg
trend.jpg
blessed.jpg
discipline.jpg
polo.jpg
