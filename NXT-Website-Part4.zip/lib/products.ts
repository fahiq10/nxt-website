export const products=[
{id:'signature-tee',name:'NXT Signature Tee',price:12000,image:'/products/signature.jpg'},
{id:'trend-tee',name:'NXT Trend Setters Tee',price:12000,image:'/products/trend.jpg'},
{id:'blessed',name:'NXT Blessed Long Sleeve',price:15000,image:'/products/blessed.jpg'},
{id:'discipline',name:'NXT Discipline Tee',price:12000,image:'/products/discipline.jpg'},
{id:'polo',name:'NXT Trend Setters Polo',price:18000,image:'/products/polo.jpg'},
];
